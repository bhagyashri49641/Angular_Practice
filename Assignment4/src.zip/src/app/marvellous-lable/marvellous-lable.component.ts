import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous-lable',
  templateUrl: './marvellous-lable.component.html',
  styleUrls: ['./marvellous-lable.component.css']
})
export class MarvellousLableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
