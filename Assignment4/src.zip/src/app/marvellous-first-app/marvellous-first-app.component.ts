import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous-first-app',
  templateUrl: './marvellous-first-app.component.html',
  styleUrls: ['./marvellous-first-app.component.css']
})
export class MarvellousFirstAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
